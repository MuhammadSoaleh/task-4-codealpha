<?php
$databaseHost = 'localhost';
$databaseUsername = '';
$databasePassword = '';
$databaseName = '';
$path2Phps = '';
$baseurl = '';?>
