﻿/*
 * FCKeditor - The text editor for internet
 * Copyright (C) 2003-2006 Frederico Caldeira Knabben
 * 
 * Licensed under the terms of the GNU Lesser General Public License:
 * 		http://www.opensource.org/licenses/lgpl-license.php
 * 
 * For further information visit:
 * 		http://www.fckeditor.net/
 * 
 * "Support Open Source software. What about a donation today?"
 * 
 * File Name: en.js
 * 	Placholder English language file.
 * 
 * File Authors:
 * 		Frederico Caldeira Knabben (fredck@fckeditor.net)
 */
FCKLang.PlaceholderBtn			= 'Insert/Edit Placeholder' ;
FCKLang.PlaceholderDlgTitle		= 'Placeholder Properties' ;
FCKLang.PlaceholderDlgName		= 'Placeholder Name' ;
FCKLang.PlaceholderErrNoName	= 'Please type the placeholder name' ;
FCKLang.PlaceholderErrNameInUse	= 'The specified name is already in use' ;