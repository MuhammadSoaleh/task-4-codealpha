<?php
header("Location: Home.php");
exit();
?>