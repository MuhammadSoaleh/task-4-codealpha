<?php
header("Location: AdminLogin.php");
exit();
?>