PHPSocial
=========

A social networking platform that just plain works. http://phpsocial.net/
This project is written in PHP