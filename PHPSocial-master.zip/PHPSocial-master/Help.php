<?php
$page = "Help";
include "Header.php";

$smarty->assign('page', $page);
include "Footer.php";
?>
